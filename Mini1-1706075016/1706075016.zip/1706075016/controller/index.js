module.exports = (req, res, next) => {
  res.send("Hello world");
};
